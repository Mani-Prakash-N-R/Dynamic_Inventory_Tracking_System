import { Employee } from "../models";
import { IRepository } from "./service";

export class EmployeeService extends IRepository<Employee> {}
