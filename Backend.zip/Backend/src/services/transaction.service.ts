import { Transaction } from "./../models";
import { IRepository } from "./service";

export class TransactionService extends IRepository<Transaction> {}
