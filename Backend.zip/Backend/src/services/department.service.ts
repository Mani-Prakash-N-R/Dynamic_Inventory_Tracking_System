import { Department } from "../models";
import { IRepository } from "./service";

export class DepartmentService extends IRepository<Department> {}
