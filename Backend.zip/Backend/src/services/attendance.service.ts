import { Attendance } from "../models";
import { IRepository } from "./service";

export class AttendanceService extends IRepository<Attendance> {}
